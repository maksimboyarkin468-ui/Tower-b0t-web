// Пароль для доступа
const CORRECT_PASSWORD = 'Q0yi54_r#dax29';

// Массив путей к картинкам (нужно будет добавить ваши картинки)
const signalImages = [
    'images/signal1.jpg',
    'images/signal2.jpg',
    'images/signal3.jpg',
    'images/signal4.jpg',
    'images/signal5.jpg',
    'images/signal6.jpg',
    'images/signal7.jpg',
    'images/signal8.jpg',
    'images/signal9.jpg',
    'images/signal10.jpg',
    'images/signal11.jpg',
    'images/signal12.jpg',
    'images/signal13.jpg',
    'images/signal14.jpg',
    'images/signal15.jpg'
];

// Текущий индекс сигнала (для цикла из 15 сообщений)
let currentSignalIndex = 0;

// Проверка пароля
function checkPassword() {
    const passwordInput = document.getElementById('passwordInput');
    const errorMessage = document.getElementById('errorMessage');
    const password = passwordInput.value.trim();
    
    if (password === CORRECT_PASSWORD) {
        // Пароль правильный - переходим к экрану сигналов
        document.getElementById('loginScreen').classList.remove('active');
        document.getElementById('signalScreen').classList.add('active');
        
        // Показываем первый сигнал
        showSignal();
        
        // Очищаем поле ввода
        passwordInput.value = '';
        errorMessage.classList.remove('show');
    } else {
        // Пароль неправильный
        errorMessage.textContent = '❌ Неверный пароль! Получите пароль у менеджера @nomep999';
        errorMessage.classList.add('show');
    }
}

// Показ сигнала
function showSignal() {
    const signalImage = document.getElementById('signalImage');
    const probabilitySpan = document.getElementById('probability');
    
    // Показываем картинку (циклически из массива)
    const imagePath = signalImages[currentSignalIndex % signalImages.length];
    signalImage.src = imagePath;
    signalImage.onerror = function() {
        // Если картинка не найдена, показываем заглушку
        this.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="400" height="300"%3E%3Crect width="400" height="300" fill="%23ddd"/%3E%3Ctext x="50%25" y="50%25" text-anchor="middle" dy=".3em" font-size="24" fill="%23999"%3EКартинка %23' + (currentSignalIndex + 1) + '%3C/text%3E%3C/svg%3E';
    };
    
    // Генерируем случайную вероятность от 85% до 98%
    const probability = Math.floor(Math.random() * (98 - 85 + 1)) + 85;
    probabilitySpan.textContent = probability;
}

// Получить следующий сигнал
function getNextSignal() {
    // Переходим к следующему сигналу (цикл из 15)
    currentSignalIndex = (currentSignalIndex + 1) % signalImages.length;
    showSignal();
}

// Вернуться назад (к началу)
function goBack() {
    // Сбрасываем индекс
    currentSignalIndex = 0;
    
    // Возвращаемся к экрану входа
    document.getElementById('signalScreen').classList.remove('active');
    document.getElementById('loginScreen').classList.add('active');
    
    // Очищаем поле пароля
    document.getElementById('passwordInput').value = '';
    document.getElementById('passwordInput').focus();
}

// Обработка нажатия Enter в поле пароля
document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.getElementById('passwordInput');
    passwordInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            checkPassword();
        }
    });
});

